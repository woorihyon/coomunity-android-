package com.jis.coommunity.detail;

/**
 * Created by lucky on 2018.04.15.
 */

public interface RemoveClickListener {
    void OnRemoveClick(int index);
}
